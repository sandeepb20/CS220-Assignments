Question 1
	Our program uses Euclidean method to solve this problem
	The output will be shown in terminal as well as gtkwave
Question 2
	Here the will enter 10 integers one after the other in a line, the code will use 
	insertion sort method to sort the 10 numbers
	Sample Test case
	9
	5
	8
	7
	4
	2
	1
	3
	6
	0
	output will be-
	0 1 2 3 4 5 6 7 8 9

Question 3
	Here the user may wish to use different values for S1 and  S0 the code specifies where
	to make the changes 
	The code will print the fibonacci numbers which are less than 500
	
Question 4
	The console will prompt the user for the value of and each value of b_i
	then it would display the value of required submission 
